function GetData() {
  return fetch("https://jsonplaceholder.typicode.com/posts").then(function (
    response
  ) {
    if (response.ok) {
      return response.json();
    }
    throw new Error("Something went wrong !");
  });
}
