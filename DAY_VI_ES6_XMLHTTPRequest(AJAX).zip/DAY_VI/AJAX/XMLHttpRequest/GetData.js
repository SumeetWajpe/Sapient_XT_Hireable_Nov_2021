function GetData(callback) {
  // AJAX
  //1. Instance of XMLHttpRequest object
  //2.Configure using open()
  //3.Send The async request
  //4. get the result

  var xmlHttpReq = new XMLHttpRequest();
  xmlHttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
  xmlHttpReq.send(); // places an async call
  xmlHttpReq.onreadystatechange = function () {
    if (xmlHttpReq.status === 200 && xmlHttpReq.readyState === 4) {
      callback(null, xmlHttpReq.responseText);
    } else if (xmlHttpReq.status !== 200 && xmlHttpReq.readyState === 4) {
      callback("Something went Wrong !" + xmlHttpReq.status, null);
    }
  };
}
