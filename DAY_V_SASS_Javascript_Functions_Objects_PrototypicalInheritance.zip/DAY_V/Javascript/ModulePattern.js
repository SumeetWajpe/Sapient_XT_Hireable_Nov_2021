var MathModule = (function (MathModule) {
  MathModule.Add = function (x, y) {
    return x + y;
  };
  function product(x, y) {
    return x * y;
  }
  return MathModule;
})(MathModule || {});
