class Point {
  constructor() {
    this.x = 10;
    this.y = 20;
  }
}

var Add = (x, y) => x + y;

module.exports = { Point, Add };
