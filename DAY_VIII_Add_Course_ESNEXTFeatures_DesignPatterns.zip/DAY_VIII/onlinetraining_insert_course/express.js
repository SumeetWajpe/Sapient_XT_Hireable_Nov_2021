const express = require("express");
const path = require("path");
const app = express();
var courses = require("./models/course.model");
app.use(express.static(path.join(__dirname, "static")));
app.use(express.json());

// app.get("/", (req, res) => res.send("Hello Express !"));
app.get("/", (req, res) => res.sendFile("Index.html", { root: __dirname }));

app.get("/courses", (req, res) => {
  res.json(courses);
});

app.post("/newcourse", (req, res) => {
  // get the data from client
  let newCourseToBeAdded = req.body;
  //immutability(functional prog)
  // courses = [...courses, newCourseToBeAdded];

  // object oriented
  courses.push(newCourseToBeAdded);
  res.json({ msg: "success" });
});
app.delete("/course/:id", (req, res) => {
  let courseId = +req.params.id;
  let index = courses.findIndex((c) => c.id === courseId);
  courses.splice(index, 1);
  res.json({ msg: "success" });
});

app.listen(5000, () => console.log("Server running at port 5000 !"));
