if ("serviceWorker" in navigator) {
  window.addEventListener("load", function () {
    navigator.serviceWorker.register("serviceworker.js").then(
      function () {
        console.log("Service Worker : Registered successfully !");
      },
      function () {
        console.log("Service Worker : Registeration failed !");
      }
    );
  });
}
