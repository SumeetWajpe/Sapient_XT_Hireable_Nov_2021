var ModuleObject = require("./module");

console.log("The addition is : " + ModuleObject.Add(20, 30));

var point = new ModuleObject.Point();
