class BasicComponent extends HTMLElement {
  constructor() {
    super();
    console.log("Within Basic Component !");
  }
}

customElements.define("uc-basic", BasicComponent);
