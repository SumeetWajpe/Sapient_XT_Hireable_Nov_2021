var largeArray = [];
//1. No access to DOM(document/window)
//2. No access to global variables from main thread
//3. No access to localStorage | sessionStorage , but access to IndexedDB
//4. Access to XMLHttpRequest (AJAX) | fetch
console.log(this);
onmessage = function (e) {
  console.log(e.data);
  for (let i = 0; i < 6000; i++) {
    largeArray[i] = [];
    for (let j = 0; j < 6000; j++) {
      largeArray[i][j] = Math.random();
    }
  }
  postMessage(largeArray[2000][3000]);
  postMessage(largeArray[1000][1000]);
  largeArray = null;// memory mgmt
};
